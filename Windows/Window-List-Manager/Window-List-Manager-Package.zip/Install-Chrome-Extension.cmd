@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Library\Install-Chrome-Extension.ps1"
if errorlevel 1 pause
