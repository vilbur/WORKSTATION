#Requires AutoHotkey v2.0
#Include ..\Window-List-Manager.ahk

original_settings_file := settings_file
settings_file := A_Temp "\WindowListManager-Test-" DllCall("GetCurrentProcessId", "UInt") ".ini"
if FileExist(settings_file)
    FileDelete(settings_file)

/*
Smoke-test sorting and default category colors.
*/
assertEqual(actual_value, expected_value, description)
{
    if (actual_value != expected_value)
        throw Error(description ": expected " expected_value ", got " actual_value)
}

entries := [
    {hwnd: 1, title: "Chrome Z", group: "chrome.exe|", priority: 5, top: "", recent: 8, order: 1},
    {hwnd: 2, title: "Max", group: "3dsmax.exe|", priority: 5, top: "", recent: 2, order: 2},
    {hwnd: 3, title: "Chrome A", group: "chrome.exe|", priority: 5, top: "", recent: 4, order: 3},
    {hwnd: 4, title: "Total Commander", group: "totalcmd64.exe|", priority: 1, top: "", recent: 1, order: 4}
]
sorted_entries := sortEntries(entries, "Alphabetical")
assertEqual(sorted_entries[1].hwnd, 4, "priority one first")
assertEqual(sorted_entries[2].hwnd, 2, "app sorting")
assertEqual(sorted_entries[3].hwnd, 3, "alphabetical Chrome title A")
assertEqual(sorted_entries[4].hwnd, 1, "alphabetical Chrome title Z")
recent_entries := sortEntries(entries, "Recent")
assertEqual(recent_entries[1].hwnd, 4, "priority survives recent sort")
assertEqual(recent_entries[2].hwnd, 2, "recent app grouping")
assertEqual(recent_entries[3].hwnd, 1, "recent Chrome Z")
assertEqual(recent_entries[4].hwnd, 3, "older Chrome A")
assertEqual(getGroupColor("3dsmax.exe", "Max"), 0x6FAEFF, "Max default color")
assertEqual(getGroupColor("chrome.exe", "ChatGPT"), 0xD998E8, "GPT default color")
assertEqual(window_list.GetCount("Column"), 1, "title-only list")
assertEqual(getDisplayTitle("Inbox - Google Chrome"), "Inbox", "Chrome suffix")
assertEqual(getDisplayTitle("Scene - Autodesk 3ds Max 2026"), "Scene", "Max suffix")
assertEqual(getDisplayTitle("Report - Other App"), "Report - Other App", "unknown suffix remains")
assertEqual(getGroupColor("chrome.exe", "Inbox", "example.com"), 0x70D58A, "default Chrome color")
IniWrite("AA7755", settings_file, "DomainColors", "example.com")
assertEqual(getGroupColor("chrome.exe", "Inbox", "example.com"), 0xAA7755, "domain color")
IniWrite("55AACC", settings_file, "Colors", "chrome.exe")
assertEqual(getGroupColor("chrome.exe", "Inbox", "example.com"), 0x55AACC, "EXE color has priority")
showOptions()
row_domains[1] := "example.com"
updateOptionsDomainList()
domain_row := 0
Loop options_domain_list.GetCount()
{
    if (options_domain_list.GetText(A_Index, 1) = "example.com")
        domain_row := A_Index
}
assertEqual(domain_row > 0, true, "domain shown in Options")
options_domain_list.Modify(domain_row, "Select")
assertEqual(optionsSelectedDomain(), "example.com", "domain selection in Options")
closeOptions()
window_list.Delete()
row_handles.Clear()
row_handles[window_list.Add("", "One")] := 111
row_handles[window_list.Add("", "Two")] := 222
last_active_hwnd := 222
selectActiveRow()
assertEqual(window_list.GetNext(), 2, "active window uses native row selection")
last_active_hwnd := 111
selectActiveRow()
assertEqual(window_list.GetNext(), 1, "selection follows active window")
last_active_hwnd := 333
selectActiveRow()
assertEqual(window_list.GetNext(), 0, "unlisted active window clears selection")
assertEqual(getAppPriority("totalcmd64.exe"), 1, "Total Commander default priority")
assertEqual(getAppPriority("chrome.exe"), 5, "other app default priority")
IniWrite("2", settings_file, "AppPriorities", "chrome.exe")
assertEqual(getAppPriority("chrome.exe"), 2, "saved app priority")
MonitorGetWorkArea(MonitorGetPrimary(), &test_left, &test_top, &test_right, &test_bottom)
assertEqual(rectangleOnScreen(test_left, test_top, 100, 100), true, "visible saved position")
assertEqual(rectangleOnScreen(1000000, 1000000, 100, 100), false, "off-screen saved position")
WinGetPos(&original_x, &original_y, &original_width, &original_height, "ahk_id " manager_gui.Hwnd)
original_center_x := original_x + original_width // 2
original_center_y := original_y + original_height // 2
test_monitor := MonitorGetPrimary()
Loop MonitorGetCount()
{
    MonitorGetWorkArea(A_Index, &work_left, &work_top, &work_right, &work_bottom)
    if (original_center_x >= work_left && original_center_x < work_right && original_center_y >= work_top && original_center_y < work_bottom)
        test_monitor := A_Index
}
MonitorGetWorkArea(test_monitor, &work_left, &work_top, &work_right, &work_bottom)
dockManager("Right", false)
WinGetPos(&docked_x, , &docked_width, , "ahk_id " manager_gui.Hwnd)
assertEqual(docked_x + docked_width <= work_right, true, "right dock stays inside monitor work area")
dockManager("Left", false)
WinGetPos(&docked_x, , , , "ahk_id " manager_gui.Hwnd)
assertEqual(docked_x >= work_left, true, "left dock stays inside monitor work area")
WinMove(original_x, original_y, original_width, original_height, "ahk_id " manager_gui.Hwnd)
assertEqual((WinGetExStyle("ahk_id " manager_gui.Hwnd) & 0x8) != 0, main_topmost, "saved main panel topmost state")
previous_lock_enabled := lock_width_enabled
previous_locked_width := locked_width
lock_width_enabled := true
locked_width := 240
minmax_info := Buffer(40, 0)
onManagerMinMax(0, minmax_info.Ptr, 0x24, manager_gui.Hwnd)
assertEqual(NumGet(minmax_info, 24, "Int"), 240, "locked minimum track width")
assertEqual(NumGet(minmax_info, 32, "Int"), 240, "locked maximum track width")
assertEqual(NumGet(minmax_info, 28, "Int"), 0, "height remains unconstrained")
lock_width_enabled := previous_lock_enabled
locked_width := previous_locked_width
assertEqual(InStr(getStartupCommand(), A_ScriptFullPath) > 0, true, "startup command points to this script")
FileDelete(settings_file)
settings_file := original_settings_file
MsgBox("SMOKE TEST PASSED. Now perform the manual UI tests in README.md.")
