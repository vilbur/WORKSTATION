# Window List Manager 0.18

**Stable MVP baseline: v0.11 (27 October 2026).** Version 0.18 continues from that baseline.

AutoHotkey v2 window switcher for Windows 11. Run `Window-List-Manager.ahk` with AutoHotkey v2.

- Narrow panel with a 16-pixel top drag strip and only window titles beneath it. Drag the strip to move the panel. Windows stay grouped internally by application, then Chrome domain when available. Choose **Sort: Recent** or **Sort: Alphabetical** from the context menu to order windows inside each group. Recent is the default; the choice survives a restart.
- App group priorities range from 1 (top) to 9 (bottom). Total Commander defaults to 1; other apps default to 5. Right click a window to set its app's priority. Equal priorities use app name to order groups.
- **Options** in the context menu edits app priorities, program and Chrome domain font colors, and recent/alphabetical sorting in one dialog. Use **Assign Color to Program** or **Assign Color to Domain** there or in a Chrome row’s right-click menu. A program color takes precedence over its domain color.
- **Lock Width** in Options fixes the panel width at its current size while leaving vertical resizing available. It survives a restart.
- **Start with Windows** in Options adds or removes a current-user Windows Run entry for this script. It is off until enabled, needs no administrator rights, and starts the same file from its current path.
- The main panel, Options window, and Ignore List open Always on Top by default. **Always on Top On** and **Always on Top Off** in the context menu control only the main panel, and that choice is saved. For a selected external window the menu shows a direct On or Off action based on its current state.
- The panel remembers its width, height, and screen position on restart. If a monitor was disconnected, it falls back to an available screen.
- Known suffixes such as ` - Google Chrome` and ` - Autodesk 3ds Max 2026` are removed from visible titles; the original title remains available for window matching.
- Click a row to activate its window. Minimized windows are restored.
- The active external window uses the same native selected-row appearance as a row clicked in the list. When the manager or its dialogs have focus, the last active external window remains selected.
- Always on Top windows have a slightly lighter row background. Right click a row to toggle the actual Windows state. The list checks for changes made elsewhere every 900 ms.
- Dark UI throughout the main panel and ignore list. Title text is green by default, blue for 3ds Max / MaxScript, and purple for ChatGPT. Color priority: explicit EXE setting, explicit domain setting, then automatic defaults. Right click a row to assign an app or domain color.
- Right click to ignore this running window, the entire application, or its exact title. **Show Ignore List** allows removal. App/title rules and colors are saved in the adjacent INI file; a single window exclusion lasts until exit.
- Right click the list and choose **Align Left** or **Align Right**. The panel uses the current monitor's work area and remembers the side for the next run.
- The context menu also offers **Move Panel** and **Exit**. The compact panel has no standard title bar buttons.
- Chrome domains come from the optional companion extension. Without it, windows remain grouped by application and the rest of the manager works. No focus stealing or clipboard based URL lookup is used.

The tool lists windows. It does not yet save or restore sessions.

## Repository layout

The root contains the AHK entry point, the two CMD launchers, the user INI and a complete ZIP package. `Library` holds runtime helpers, the icon, Chrome extension and build scripts. `Documents` holds this README, and `Tests` holds the AHK smoke test. Keep this folder structure when extracting the ZIP.

## Icon and Windows EXE

`Library\Window-List-Manager.ico` includes hand-drawn 16px artwork and 24, 32, 48, 64, 128 and 256px layers. Keep the Library folder next to the script or EXE for the tray and panel window icons. The main EXE also embeds the icon.

On Windows with AutoHotkey v2 and its Ahk2Exe compiler installed, double click `Build-EXE.cmd` in the root folder. It creates `Window-List-Manager.exe` here. Keep the Library folder beside the EXE if using Chrome domains. In Options, toggle Start with Windows off and back on after switching from the AHK script to the EXE; the registry entry then points to the EXE. The EXE must be built on Windows; this distribution contains the script, icon, and build helper.

## Chrome domain setup

1. Keep `Library\Chrome-Domain-Bridge.ps1` beside the AHK script or EXE. The manager starts this local helper automatically.
2. Keep the Library folder beside `Install-Chrome-Extension.cmd` and double click the CMD file. It extracts the extension to `%LOCALAPPDATA%\WindowListManager\Chrome-Extension`, opens that folder, and opens `chrome://extensions/` in Chrome.
3. In Chrome enable **Developer mode**, click **Load unpacked**, and select the opened extension folder. Chrome requires this confirmation for an unpacked extension; the installer does not bypass it. Keep the installed folder in place.
4. Restart Window List Manager, then switch between Chrome windows once. Domain groups and colors will update. The extension also refreshes its data every 30 seconds.

The extension reads the active tab of each Chrome window and sends only its title, domain and window rectangle to a listener bound to `127.0.0.1:18763`. It does not send full URLs or browsing history elsewhere. Matching a Chrome window to its tab uses the title and rectangle; two windows with identical titles and nearly identical positions can be ambiguous. Browser pages without an HTTP(S) URL have no domain group.

## Manual test

1. Open two Chrome windows and one other app. Confirm three rows appear and clicking each activates the right window.
2. Pin one window on top with another tool. Within a second its row should become lighter; toggle it through the row menu and confirm the row returns to the normal background.
3. Set a custom color for an app, ignore one window and one app, then open **Show Ignore List** and remove both rules. The app color and persistent rule should survive a restart.
4. Minimize a window and click its row; confirm it is restored.
5. Align the panel to each edge on a secondary monitor, confirm it stays inside both edges, restart, and confirm the chosen edge is restored.
6. Drag the narrow top strip and confirm the panel moves with the mouse.
7. Install the extension, open two Chrome windows on different domains, and confirm they remain together under Chrome but are sorted by domain internally. Set an app color, then a domain color: the app color should win.
8. Resize and move the panel, restart it, and confirm its rectangle is restored. In Options set a priority, program color, and domain color; close and reopen Options and confirm all values persist. Reset the program color and confirm the domain color becomes visible.
9. Enable **Lock Width**, try dragging both side edges and the bottom edge, then restart. Confirm horizontal resizing remains locked, vertical resizing still works, and disabling it restores horizontal resizing.
10. Switch between two listed applications and confirm the selected row follows focus and looks the same as a row selected by clicking. Focus the manager panel and Options, and confirm the previous external window remains selected.
11. In Options enable **Start with Windows** and confirm the `WindowListManager` value appears under `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`. Disable it and confirm that value is removed. Re-enable it and sign out/in to check startup.

This version was statically reviewed in a non-Windows environment; the manual Windows test remains necessary.

Version 0.18 adds a persistent Lock Width option. Version 0.17 offsets left and right docking by 8 pixels to keep the panel inside the monitor edges. Version 0.16 organizes the root, Library, Documents and Tests and provides a single ZIP package. Version 0.15 adds domain color controls in Options and consistent Assign Color to Program/Domain labels. Version 0.14 selects the active window row with the native ListView selection. Version 0.13 added the multi-resolution icon and an Ahk2Exe build helper. Version 0.12 added the user-level Start with Windows option. Chrome domain data uses an optional local extension, and known application suffixes are removed from visible titles. Recent tracks window activations observed while the manager is running; windows without a recorded activation initially use the current Windows order. Some native Windows menu and color picker surfaces continue to use the system theme.
