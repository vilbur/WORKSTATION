#Requires AutoHotkey v2.0
#SingleInstance Force

/*
Window List Manager 0.18. Stable MVP baseline: v0.11.
Run with AutoHotkey v2 on Windows 10/11.
*/

global app_version := "0.18"
global settings_file := A_ScriptDir "\Window-List-Manager.ini"
global startup_key := "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run"
global startup_value_name := "WindowListManager"
global main_topmost := IniRead(settings_file, "Panel", "AlwaysOnTop", "1") != "0"
global lock_width_enabled := IniRead(settings_file, "Panel", "LockWidth", "0") = "1"
global locked_width := 0
global domain_file := A_Temp "\WindowListManager-" DllCall("GetCurrentProcessId", "UInt") ".tsv"
global sort_mode := IniRead(settings_file, "Panel", "SortMode", "Recent")
global recent_order := Map()
global recent_counter := 0
global last_active_hwnd := 0
global manager_gui := Gui("-Caption -Border +Resize +AlwaysOnTop +MinSize140x150", "Window List Manager v" app_version)
manager_gui.BackColor := "202124"
manager_gui.SetFont("s12 cE8EAED", "Segoe UI")
global drag_bar := manager_gui.AddText("x1 y1 w218 h16 Background343A43 +0x100", "")
global window_list := manager_gui.AddListView("x1 y18 w218 h481 -Multi -Hdr", ["Window Title"])
global row_handles := Map()
global row_colors := Map()
global row_groups := Map()
global row_domains := Map()
global row_topmost := Map()
global ignore_hwnds := Map()
global menu_target := 0
global menu_group := ""
global menu_domain := ""
global ignore_gui := ""
global ignore_list := ""
global options_gui := ""
global options_list := ""
global options_domain_list := ""
global options_sort := ""
global options_startup := ""
global options_lock_width := ""
global refresh_busy := false

window_list.ModifyCol(1, 214)
window_list.OnEvent("Click", onWindowClick)
window_list.OnEvent("ContextMenu", onWindowContextMenu)
manager_gui.OnEvent("Size", onManagerResize)
manager_gui.OnEvent("Close", (*) => ExitApp())
OnMessage(0x4E, onListNotify)
OnMessage(0x201, onDragBarDown)
OnMessage(0x24, onManagerMinMax)
manager_gui.Show("w220 h500")
applyManagerIcon()
manager_gui.Opt(main_topmost ? "+AlwaysOnTop" : "-AlwaysOnTop")
applyDarkTheme(manager_gui, window_list)
startDomainBridge()
restoreManagerPosition()
if lock_width_enabled
    captureLockedWidth()
refreshWindows()
SetTimer(refreshWindows, 900)
SetTimer(saveManagerPosition, 1200)
OnExit((*) => saveManagerPosition())

/* Use the 16px icon for the taskbar's small slot and 32px for the large slot. */
applyManagerIcon()
{
    icon_path := A_ScriptDir "\Library\Window-List-Manager.ico"
    if !FileExist(icon_path)
        return
    try TraySetIcon(icon_path)
    for slot, size in [[0, 16], [1, 32]]
    {
        handle := DllCall("user32\LoadImageW", "Ptr", 0, "WStr", icon_path,
            "UInt", 1, "Int", size[2], "Int", size[2], "UInt", 0x10, "Ptr")
        if handle
            DllCall("user32\SendMessageW", "Ptr", manager_gui.Hwnd,
                "UInt", 0x80, "UPtr", slot, "Ptr", handle, "Ptr")
    }
}

/*
Resize the window list with the manager dialog.
*/
onManagerResize(gui_obj, min_max, width, height)
{
    if (min_max = -1)
        return
    drag_bar.Move(1, 1, width - 2, 16)
    window_list.Move(1, 18, width - 2, height - 19)
    window_list.ModifyCol(1, width - 6)
}

/*
Record the current outer width for the panel resize constraint.
*/
captureLockedWidth()
{
    global locked_width
    WinGetPos(, , &locked_width, , "ahk_id " manager_gui.Hwnd)
}

/*
Constrain only the panel's width while leaving its height resizable.
*/
onManagerMinMax(w_param, l_param, msg, hwnd)
{
    if (hwnd != manager_gui.Hwnd || !lock_width_enabled || locked_width <= 0)
        return
    NumPut("Int", locked_width, l_param, 24)
    NumPut("Int", locked_width, l_param, 32)
    return 0
}

/*
Restore the previous rectangle if it still intersects a connected display.
*/
restoreManagerPosition()
{
    x := IniRead(settings_file, "Panel", "X", "")
    y := IniRead(settings_file, "Panel", "Y", "")
    width := IniRead(settings_file, "Panel", "Width", "")
    height := IniRead(settings_file, "Panel", "Height", "")
    if (x != "" && y != "" && width != "" && height != "")
    {
        try
        {
            x := Integer(x)
            y := Integer(y)
            width := Integer(width)
            height := Integer(height)
            if (width >= 140 && height >= 150 && rectangleOnScreen(x, y, width, height))
            {
                manager_gui.Show("x" x " y" y " w" width " h" height)
                return
            }
        }
    }
    saved_side := IniRead(settings_file, "Panel", "DockSide", "")
    if (saved_side = "Left" || saved_side = "Right")
        dockManager(saved_side, false)
}

/*
Check that at least part of a saved panel rectangle is reachable.
*/
rectangleOnScreen(x, y, width, height)
{
    Loop MonitorGetCount()
    {
        MonitorGetWorkArea(A_Index, &left, &top, &right, &bottom)
        if (x < right && x + width > left && y < bottom && y + height > top)
            return true
    }
    return false
}

/*
Save panel geometry only when it has changed.
*/
saveManagerPosition(*)
{
    static previous_geometry := ""
    try
    {
        if (WinGetMinMax("ahk_id " manager_gui.Hwnd) = -1)
            return
        WinGetPos(&x, &y, &width, &height, "ahk_id " manager_gui.Hwnd)
        current_geometry := x "," y "," width "," height
        if (current_geometry = previous_geometry)
            return
        previous_geometry := current_geometry
        IniWrite(x, settings_file, "Panel", "X")
        IniWrite(y, settings_file, "Panel", "Y")
        IniWrite(width, settings_file, "Panel", "Width")
        IniWrite(height, settings_file, "Panel", "Height")
    }
}

/*
Start a native window move when the narrow top strip is pressed.
*/
onDragBarDown(w_param, l_param, msg, control_hwnd)
{
    if (control_hwnd != drag_bar.Hwnd)
        return
    DllCall("user32\ReleaseCapture")
    DllCall("user32\SendMessageW", "Ptr", manager_gui.Hwnd, "UInt", 0xA1, "UPtr", 2, "Ptr", 0, "Ptr")
    return 0
}

/*
Return whether a window belongs in the normal top-level window list.
*/
isListedWindow(hwnd)
{
    if (hwnd = manager_gui.Hwnd)
        return false
    if (ignore_gui != "" && hwnd = ignore_gui.Hwnd)
        return false
    if (options_gui != "" && hwnd = options_gui.Hwnd)
        return false
    if !DllCall("IsWindowVisible", "Ptr", hwnd, "Int")
        return false
    if (WinGetTitle("ahk_id " hwnd) = "")
        return false
    if (WinGetExStyle("ahk_id " hwnd) & 0x80)
        return false
    if DllCall("GetWindow", "Ptr", hwnd, "UInt", 4, "Ptr")
        return false
    cloaked := Buffer(4, 0)
    if (DllCall("dwmapi\DwmGetWindowAttribute", "Ptr", hwnd, "UInt", 14, "Ptr", cloaked.Ptr, "UInt", 4, "Int") = 0 && NumGet(cloaked, 0, "UInt"))
        return false
    return true
}

/*
Read persisted ignore rules for one window.
*/
isIgnored(hwnd, exe_name, title)
{
    if ignore_hwnds.Has(hwnd)
        return true
    if (IniRead(settings_file, "IgnoreApps", exe_name, "0") = "1")
        return true
    return (IniRead(settings_file, "IgnoreTitles", title, "0") = "1")
}

/*
Read the saved group color or select a default based on the title.
*/
getGroupColor(group_name, title, domain := "")
{
    color_hex := IniRead(settings_file, "Colors", group_name, "")
    if RegExMatch(color_hex, "i)^[0-9a-f]{6}$")
        return Integer("0x" color_hex)
    if (domain != "")
    {
        color_hex := IniRead(settings_file, "DomainColors", domain, "")
        if RegExMatch(color_hex, "i)^[0-9a-f]{6}$")
            return Integer("0x" color_hex)
    }
    if RegExMatch(group_name, "i)3dsmax")
        return 0x6FAEFF
    if RegExMatch(domain, "i)(^|\.)chatgpt\.com$|(^|\.)openai\.com$")
        return 0xD998E8
    if RegExMatch(title, "i)GPT|ChatGPT")
        return 0xD998E8
    if RegExMatch(group_name " " title, "i)MaxScript")
        return 0x6FAEFF
    return 0x70D58A
}

/*
Remove a known application suffix from the visible window title.
*/
getDisplayTitle(title)
{
    return RegExReplace(title, "i)\s+-\s+(?:Google Chrome|Autodesk 3ds Max(?: 20\d\d)?|3ds Max(?: 20\d\d)?|Autodesk 3D Studio Max)\s*$", "")
}

/*
Get an app's numeric group priority; one is highest.
*/
getAppPriority(app_name)
{
    default_priority := RegExMatch(app_name, "i)^totalcmd(64)?\.exe$") ? 1 : 5
    saved_priority := IniRead(settings_file, "AppPriorities", app_name, default_priority)
    if RegExMatch(saved_priority, "^[1-9]$")
        return Integer(saved_priority)
    return default_priority
}

/*
Start the local Chrome bridge without modifying browser focus or clipboard.
*/
startDomainBridge()
{
    bridge_script := A_ScriptDir "\Library\Chrome-Domain-Bridge.ps1"
    if !FileExist(bridge_script)
        return
    quote := Chr(34)
    manager_pid := DllCall("GetCurrentProcessId", "UInt")
    command := "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " quote bridge_script quote " -OutputPath " quote domain_file quote " -ManagerPid " manager_pid
    try Run(command, , "Hide")
}

/*
Read active Chrome tab domains sent by the companion extension.
*/
readChromeDomains()
{
    records := []
    if !FileExist(domain_file)
        return records
    try
    {
        for line in StrSplit(FileRead(domain_file, "UTF-8"), "`n")
        {
            fields := StrSplit(Trim(line, "`r"), "`t")
            if (fields.Length < 6)
                continue
            records.Push({title: fields[1], domain: fields[2], left: Integer(fields[3]), top: Integer(fields[4]), width: Integer(fields[5]), height: Integer(fields[6])})
        }
    }
    return records
}

/*
Match a Chrome HWND with its active tab by title and window position.
*/
matchChromeDomain(hwnd, title, records)
{
    best_score := -1
    best_domain := ""
    chrome_title := StrLower(title)
    try WinGetPos(&win_x, &win_y, &win_width, &win_height, "ahk_id " hwnd)
    catch
        return ""
    for record in records
    {
        page_title := StrLower(record.title)
        if (page_title = "" || !InStr(chrome_title, page_title))
            continue
        distance := Abs(win_x - record.left) + Abs(win_y - record.top) + Abs(win_width - record.width) + Abs(win_height - record.height)
        score := 100000 - Min(distance, 90000)
        if (score > best_score)
        {
            best_score := score
            best_domain := record.domain
        }
    }
    return best_domain
}

/*
Apply dark colors to a dialog, its list, and the Windows title bar.
*/
applyDarkTheme(gui_obj, list_obj)
{
    dark_enabled := Buffer(4, 0)
    NumPut("Int", 1, dark_enabled)
    DllCall("dwmapi\DwmSetWindowAttribute", "Ptr", gui_obj.Hwnd, "UInt", 20, "Ptr", dark_enabled.Ptr, "UInt", 4, "Int")
    DllCall("uxtheme\SetWindowTheme", "Ptr", list_obj.Hwnd, "WStr", "DarkMode_Explorer", "Ptr", 0, "Int")
    header_hwnd := DllCall("user32\SendMessageW", "Ptr", list_obj.Hwnd, "UInt", 0x101F, "UPtr", 0, "Ptr", 0, "Ptr")
    if header_hwnd
        DllCall("uxtheme\SetWindowTheme", "Ptr", header_hwnd, "WStr", "DarkMode_Explorer", "Ptr", 0, "Int")
    background := toColorRef(0x202124)
    foreground := toColorRef(0xE8EAED)
    DllCall("user32\SendMessageW", "Ptr", list_obj.Hwnd, "UInt", 0x1001, "UPtr", 0, "Ptr", background, "Ptr")
    DllCall("user32\SendMessageW", "Ptr", list_obj.Hwnd, "UInt", 0x1026, "UPtr", 0, "Ptr", background, "Ptr")
    DllCall("user32\SendMessageW", "Ptr", list_obj.Hwnd, "UInt", 0x1024, "UPtr", 0, "Ptr", foreground, "Ptr")
}

/*
Convert an RGB value to the COLORREF byte order used by Windows controls.
*/
toColorRef(rgb)
{
    return ((rgb & 0xFF) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 0xFF)
}

/*
Collect open windows and refresh only when their visible data changes.
*/
refreshWindows(force := false)
{
    global refresh_busy, recent_counter, last_active_hwnd
    static last_signature := ""
    if refresh_busy
        return
    refresh_busy := true
    try
    {
        active_hwnd := WinGetID("A")
        active_changed := false
        if (active_hwnd != last_active_hwnd && active_hwnd != manager_gui.Hwnd && (ignore_gui = "" || active_hwnd != ignore_gui.Hwnd) && (options_gui = "" || active_hwnd != options_gui.Hwnd))
        {
            recent_counter += 1
            recent_order[active_hwnd] := recent_counter
            last_active_hwnd := active_hwnd
            active_changed := true
        }
        entries := []
        chrome_records := readChromeDomains()
        signature := ""
        for hwnd in WinGetList()
        {
            try
            {
                if !isListedWindow(hwnd)
                    continue
                title := WinGetTitle("ahk_id " hwnd)
                exe_name := WinGetProcessName("ahk_id " hwnd)
                if isIgnored(hwnd, exe_name, title)
                    continue
                top := (WinGetExStyle("ahk_id " hwnd) & 0x8) ? "TOP" : ""
                app_name := StrLower(exe_name)
                domain := app_name = "chrome.exe" ? matchChromeDomain(hwnd, title, chrome_records) : ""
                group_name := app_name "|" domain
                entries.Push({hwnd: hwnd, title: getDisplayTitle(title), app: app_name, domain: domain, group: group_name, priority: getAppPriority(app_name), top: top, recent: recent_order.Get(hwnd, 0), order: entries.Length + 1})
                signature .= group_name "|" hwnd "|" title "|" top "`n"
            }
        }
        if (signature = last_signature && !force && !(sort_mode = "Recent" && active_changed))
        {
            if active_changed
                selectActiveRow()
            return
        }
        last_signature := signature
        entries := sortEntries(entries, sort_mode)
        window_list.Opt("-Redraw")
        window_list.Delete()
        row_handles.Clear()
        row_colors.Clear()
        row_groups.Clear()
        row_domains.Clear()
        row_topmost.Clear()
        for entry in entries
        {
            row := window_list.Add("", entry.title)
            row_handles[row] := entry.hwnd
            row_groups[row] := entry.app
            row_domains[row] := entry.domain
            row_topmost[row] := entry.top != ""
            row_colors[row] := getGroupColor(entry.app, entry.title, entry.domain)
        }
        selectActiveRow()
        window_list.Opt("+Redraw")
        if (ignore_gui != "")
            updateIgnoreList()
    }
    finally
        refresh_busy := false
}

/*
Sort by numeric app priority, app/domain, then recent use or title.
*/
sortEntries(entries, mode := "Alphabetical")
{
    result := []
    for entry in entries
    {
        insert_at := result.Length + 1
        for index, current in result
        {
            priority_compare := entry.priority - current.priority
            group_compare := StrCompare(entry.group, current.group)
            recent_first := mode = "Recent" && (entry.recent > current.recent || (entry.recent = current.recent && entry.order < current.order))
            alphabet_first := mode != "Recent" && StrCompare(entry.title, current.title) < 0
            if (priority_compare < 0 || (priority_compare = 0 && (group_compare < 0 || (group_compare = 0 && (recent_first || alphabet_first)))))
            {
                insert_at := index
                break
            }
        }
        result.InsertAt(insert_at, entry)
    }
    return result
}

/*
Activate the clicked window and restore it first if minimized.
*/
onWindowClick(control, row)
{
    if (row < 1 || !row_handles.Has(row))
        return
    hwnd := row_handles[row]
    try
    {
        if (WinGetMinMax("ahk_id " hwnd) = -1)
            WinRestore("ahk_id " hwnd)
        WinActivate("ahk_id " hwnd)
    }
}

/*
Build context actions for a window or the blank part of the list.
*/
onWindowContextMenu(control, row, is_right_click, x, y)
{
    global menu_target, menu_group, menu_domain
    menu_target := row_handles.Has(row) ? row_handles[row] : 0
    menu_group := row_groups.Has(row) ? row_groups[row] : ""
    menu_domain := row_domains.Has(row) ? row_domains[row] : ""
    context_menu := Menu()
    if menu_target
    {
        target_is_topmost := (WinGetExStyle("ahk_id " menu_target) & 0x8) != 0
        if target_is_topmost
            context_menu.Add("Window: Always on Top Off", disableTargetTop)
        else
            context_menu.Add("Window: Always on Top On", enableTargetTop)
        context_menu.Add("Assign Color to Program...", assignGroupColor)
        context_menu.Add("App Priority (" getAppPriority(menu_group) ")...", assignAppPriority)
        if (menu_domain != "")
            context_menu.Add("Assign Color to Domain...", assignDomainColor)
        context_menu.Add()
        context_menu.Add("Ignore This Window", ignoreTargetWindow)
        context_menu.Add("Ignore This App", ignoreTargetApp)
        context_menu.Add("Ignore This Title", ignoreTargetTitle)
        context_menu.Add()
    }
    context_menu.Add("Show Ignore List", showIgnoreList)
    context_menu.Add("Options...", showOptions)
    context_menu.Add()
    context_menu.Add("Always on Top On", enableMainTop)
    context_menu.Add("Always on Top Off", disableMainTop)
    context_menu.Check(main_topmost ? "Always on Top On" : "Always on Top Off")
    context_menu.Add()
    context_menu.Add("Sort: Recent", selectRecentSort)
    context_menu.Add("Sort: Alphabetical", selectAlphabeticalSort)
    context_menu.Check(sort_mode = "Recent" ? "Sort: Recent" : "Sort: Alphabetical")
    context_menu.Add()
    context_menu.Add("Align Left", alignLeft)
    context_menu.Add("Align Right", alignRight)
    context_menu.Add("Move Panel", movePanel)
    context_menu.Add()
    context_menu.Add("Exit", (*) => ExitApp())
    context_menu.Show()
}

/*
Sort app groups by the most recently activated window first.
*/
selectRecentSort(*)
{
    global sort_mode
    sort_mode := "Recent"
    IniWrite(sort_mode, settings_file, "Panel", "SortMode")
    refreshWindows(true)
}

/*
Sort titles alphabetically inside each app group.
*/
selectAlphabeticalSort(*)
{
    global sort_mode
    sort_mode := "Alphabetical"
    IniWrite(sort_mode, settings_file, "Panel", "SortMode")
    refreshWindows(true)
}

/*
Open settings for app priority, app font color, and sort mode.
*/
showOptions(*)
{
    global options_gui, options_list, options_domain_list, options_sort, options_startup, options_lock_width
    if (options_gui != "")
    {
        options_gui.Show()
        return
    }
    options_gui := Gui("+Owner" manager_gui.Hwnd " +AlwaysOnTop", "Window List Manager Options")
    options_gui.BackColor := "202124"
    options_gui.SetFont("s10 cE8EAED", "Segoe UI")
    options_gui.AddText("x12 y12 w85 h24", "Sort mode:")
    options_sort := options_gui.AddDropDownList("x98 y10 w160", ["Recent", "Alphabetical"])
    options_sort.Choose(sort_mode = "Recent" ? 1 : 2)
    options_sort.OnEvent("Change", changeOptionsSort)
    options_list := options_gui.AddListView("x12 y46 w430 h204 -Multi", ["Application", "Priority", "Font color"])
    options_list.ModifyCol(1, 215)
    options_list.ModifyCol(2, 70)
    options_list.ModifyCol(3, 120)
    options_gui.AddButton("x12 y259 w105", "Set Priority").OnEvent("Click", optionsSetPriority)
    options_gui.AddButton("x124 y259 w160", "Assign Color to Program").OnEvent("Click", optionsSetColor)
    options_gui.AddButton("x291 y259 w151", "Reset Program Color").OnEvent("Click", optionsResetColor)
    options_gui.AddText("x12 y297 w430 h22", "Chrome domains (app color takes precedence)")
    options_domain_list := options_gui.AddListView("x12 y322 w430 h165 -Multi", ["Domain", "Font color"])
    options_domain_list.ModifyCol(1, 282)
    options_domain_list.ModifyCol(2, 125)
    options_gui.AddButton("x12 y495 w160", "Assign Color to Domain").OnEvent("Click", optionsSetDomainColor)
    options_gui.AddButton("x179 y495 w135", "Reset Domain Color").OnEvent("Click", optionsResetDomainColor)
    options_gui.AddButton("x321 y495 w121", "Ignore List").OnEvent("Click", showIgnoreList)
    options_startup := options_gui.AddCheckBox("x12 y537 w220 h24", "Start with Windows")
    options_startup.Value := isStartupEnabled() ? 1 : 0
    options_startup.OnEvent("Click", changeStartupSetting)
    options_lock_width := options_gui.AddCheckBox("x235 y537 w200 h24", "Lock Width")
    options_lock_width.Value := lock_width_enabled ? 1 : 0
    options_lock_width.OnEvent("Click", changeWidthLock)
    options_gui.OnEvent("Close", closeOptions)
    options_gui.Show("w454 h575")
    applyDarkTheme(options_gui, options_list)
    applyDarkTheme(options_gui, options_domain_list)
    updateOptionsList()
}

/*
Close the options dialog without changing saved settings.
*/
closeOptions(*)
{
    global options_gui, options_list, options_domain_list, options_sort, options_startup, options_lock_width
    options_gui.Destroy()
    options_gui := ""
    options_list := ""
    options_domain_list := ""
    options_sort := ""
    options_startup := ""
    options_lock_width := ""
}

/*
Save the width lock and capture the current panel width when enabled.
*/
changeWidthLock(*)
{
    global lock_width_enabled, locked_width
    lock_width_enabled := options_lock_width.Value = 1
    if lock_width_enabled
        captureLockedWidth()
    else
        locked_width := 0
    IniWrite(lock_width_enabled ? "1" : "0", settings_file, "Panel", "LockWidth")
}

/*
Build the user-level startup command for this script or compiled executable.
*/
getStartupCommand()
{
    quote := Chr(34)
    if A_IsCompiled
        return quote A_ScriptFullPath quote
    return quote A_AhkPath quote " " quote A_ScriptFullPath quote
}

/*
Check whether the Run entry points to this exact manager.
*/
isStartupEnabled()
{
    current_command := RegRead(startup_key, startup_value_name, "")
    return current_command = getStartupCommand()
}

/*
Add or remove the current-user Windows startup entry.
*/
changeStartupSetting(*)
{
    try
    {
        if options_startup.Value
            RegWrite(getStartupCommand(), "REG_SZ", startup_key, startup_value_name)
        else
            RegDelete(startup_key, startup_value_name)
    }
    catch as error
    {
        options_startup.Value := isStartupEnabled() ? 1 : 0
        MsgBox("Windows startup setting could not be saved: " error.Message, "Window List Manager")
    }
}

/*
List each currently visible application group once.
*/
updateOptionsList()
{
    if (options_gui = "")
        return
    selected_app := optionsSelectedApp()
    options_list.Delete()
    seen := Map()
    for row, app_name in row_groups
    {
        if seen.Has(app_name)
            continue
        seen[app_name] := true
        color_hex := IniRead(settings_file, "Colors", app_name, "Auto")
        item := options_list.Add("", app_name, getAppPriority(app_name), color_hex)
        if (app_name = selected_app)
            options_list.Modify(item, "Select")
    }
    updateOptionsDomainList()
}

/*
List visible Chrome domains and saved domain color rules in Options.
*/
updateOptionsDomainList()
{
    if (options_domain_list = "")
        return
    selected_domain := optionsSelectedDomain()
    options_domain_list.Delete()
    domains := Map()
    for row, domain in row_domains
    {
        if (domain != "")
            domains[domain] := true
    }
    try
    {
        for line in StrSplit(IniRead(settings_file, "DomainColors"), "`n")
        {
            split_at := InStr(line, "=")
            if split_at
                domains[SubStr(line, 1, split_at - 1)] := true
        }
    }
    for domain in domains
    {
        color_hex := IniRead(settings_file, "DomainColors", domain, "Auto")
        item := options_domain_list.Add("", domain, color_hex)
        if (domain = selected_domain)
            options_domain_list.Modify(item, "Select")
    }
}

/*
Get the selected Chrome domain from the Options dialog.
*/
optionsSelectedDomain()
{
    if (options_domain_list = "")
        return ""
    row := options_domain_list.GetNext()
    return row ? options_domain_list.GetText(row, 1) : ""
}

/*
Assign the selected domain's font color without changing its app color.
*/
optionsSetDomainColor(*)
{
    domain := optionsSelectedDomain()
    if (domain = "")
        return
    color_hex := IniRead(settings_file, "DomainColors", domain, "")
    initial_color := RegExMatch(color_hex, "i)^[0-9a-f]{6}$") ? Integer("0x" color_hex) : getGroupColor("chrome.exe", "", domain)
    color := chooseColor(initial_color, options_gui.Hwnd)
    if (color < 0)
        return
    IniWrite(Format("{:06X}", color), settings_file, "DomainColors", domain)
    refreshWindows(true)
    updateOptionsDomainList()
}

/*
Remove the selected domain rule and restore the automatic color.
*/
optionsResetDomainColor(*)
{
    domain := optionsSelectedDomain()
    if (domain = "")
        return
    try IniDelete(settings_file, "DomainColors", domain)
    refreshWindows(true)
    updateOptionsDomainList()
}

/*
Get the application selected for editing in Options.
*/
optionsSelectedApp()
{
    if (options_gui = "")
        return ""
    row := options_list.GetNext()
    return row ? options_list.GetText(row, 1) : ""
}

/*
Persist the sort choice made in Options.
*/
changeOptionsSort(*)
{
    global sort_mode
    sort_mode := options_sort.Text
    IniWrite(sort_mode, settings_file, "Panel", "SortMode")
    refreshWindows(true)
}

/*
Prompt for the selected app's priority and refresh the list.
*/
optionsSetPriority(*)
{
    app_name := optionsSelectedApp()
    if (app_name = "")
        return
    choice := InputBox("Priority for " app_name " (1 first, 9 last):", "App Priority", "w300 h135", getAppPriority(app_name))
    if (choice.Result != "OK")
        return
    if !RegExMatch(Trim(choice.Value), "^[1-9]$")
    {
        MsgBox("Enter one number from 1 to 9.", "App Priority")
        return
    }
    IniWrite(Trim(choice.Value), settings_file, "AppPriorities", app_name)
    refreshWindows(true)
    updateOptionsList()
}

/*
Assign a font color to every window of the selected app.
*/
optionsSetColor(*)
{
    app_name := optionsSelectedApp()
    if (app_name = "")
        return
    color := chooseColor(getGroupColor(app_name, ""), options_gui.Hwnd)
    if (color < 0)
        return
    IniWrite(Format("{:06X}", color), settings_file, "Colors", app_name)
    refreshWindows(true)
    updateOptionsList()
}

/*
Remove an explicit app color so domain and default colors can apply.
*/
optionsResetColor(*)
{
    app_name := optionsSelectedApp()
    if (app_name = "")
        return
    try IniDelete(settings_file, "Colors", app_name)
    refreshWindows(true)
    updateOptionsList()
}

/*
Let Windows move the captionless panel after its context menu closes.
*/
movePanel(*)
{
    DllCall("user32\ReleaseCapture")
    PostMessage(0xA1, 2, 0, , "ahk_id " manager_gui.Hwnd)
}

/*
Align the manager to the left edge of its current display.
*/
alignLeft(*)
{
    dockManager("Left")
}

/*
Align the manager to the right edge of its current display.
*/
alignRight(*)
{
    dockManager("Right")
}

/*
Fill the current monitor work area's height at the chosen edge.
*/
dockManager(side, save_choice := true)
{
    WinGetPos(&window_x, &window_y, &window_width, &window_height, "ahk_id " manager_gui.Hwnd)
    center_x := window_x + window_width // 2
    center_y := window_y + window_height // 2
    monitor_index := MonitorGetPrimary()
    Loop MonitorGetCount()
    {
        MonitorGetWorkArea(A_Index, &left, &top, &right, &bottom)
        if (center_x >= left && center_x < right && center_y >= top && center_y < bottom)
        {
            monitor_index := A_Index
            break
        }
    }
    MonitorGetWorkArea(monitor_index, &left, &top, &right, &bottom)
    window_width := Min(window_width, right - left)
    work_height := bottom - top
    target_x := side = "Right" ? right - window_width - 8 : left + 8
    manager_gui.Show("x" target_x " y" top " w" window_width " h" work_height)
    if save_choice
        IniWrite(side, settings_file, "Panel", "DockSide")
}

/*
Enable Always on Top for the selected external window.
*/
enableTargetTop(*)
{
    try WinSetAlwaysOnTop(1, "ahk_id " menu_target)
    refreshWindows()
}

/*
Disable Always on Top for the selected external window.
*/
disableTargetTop(*)
{
    try WinSetAlwaysOnTop(0, "ahk_id " menu_target)
    refreshWindows()
}

/*
Keep the main panel above other windows and save the choice.
*/
enableMainTop(*)
{
    global main_topmost
    main_topmost := true
    manager_gui.Opt("+AlwaysOnTop")
    IniWrite("1", settings_file, "Panel", "AlwaysOnTop")
}

/*
Allow other windows to cover the main panel and save the choice.
*/
disableMainTop(*)
{
    global main_topmost
    main_topmost := false
    manager_gui.Opt("-AlwaysOnTop")
    IniWrite("0", settings_file, "Panel", "AlwaysOnTop")
}

/*
Open the Windows color picker and save a title font color per app group.
*/
assignGroupColor(*)
{
    if (menu_group = "")
        return
    color := chooseColor(getGroupColor(menu_group, ""), manager_gui.Hwnd)
    if (color < 0)
        return
    IniWrite(Format("{:06X}", color), settings_file, "Colors", menu_group)
    refreshWindows(true)
}

/*
Save a Chrome domain color, subordinate to an explicit EXE color.
*/
assignDomainColor(*)
{
    if (menu_domain = "")
        return
    color := chooseColor(getGroupColor(menu_group, "", menu_domain), manager_gui.Hwnd)
    if (color < 0)
        return
    IniWrite(Format("{:06X}", color), settings_file, "DomainColors", menu_domain)
    refreshWindows(true)
}

/*
Save priority one through nine for the selected application group.
*/
assignAppPriority(*)
{
    if (menu_group = "")
        return
    choice := InputBox("Priority for " menu_group " (1 first, 9 last):", "App Priority", "w300 h135", getAppPriority(menu_group))
    if (choice.Result != "OK")
        return
    if !RegExMatch(Trim(choice.Value), "^[1-9]$")
    {
        MsgBox("Enter one number from 1 to 9.", "App Priority")
        return
    }
    IniWrite(Trim(choice.Value), settings_file, "AppPriorities", menu_group)
    refreshWindows(true)
}

/*
Choose an RGB color through the standard Windows color dialog.
*/
chooseColor(rgb, owner_hwnd)
{
    custom_colors := Buffer(64, 0)
    chooser := Buffer(A_PtrSize = 8 ? 72 : 36, 0)
    color_ref := ((rgb & 0xFF) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 0xFF)
    NumPut("UInt", chooser.Size, chooser, 0)
    NumPut("Ptr", owner_hwnd, chooser, A_PtrSize = 8 ? 8 : 4)
    NumPut("UInt", color_ref, chooser, A_PtrSize = 8 ? 24 : 12)
    NumPut("Ptr", custom_colors.Ptr, chooser, A_PtrSize = 8 ? 32 : 16)
    NumPut("UInt", 0x103, chooser, A_PtrSize = 8 ? 40 : 20)
    if !DllCall("comdlg32\ChooseColorW", "Ptr", chooser.Ptr, "Int")
        return -1
    chosen := NumGet(chooser, A_PtrSize = 8 ? 24 : 12, "UInt")
    return ((chosen & 0xFF) << 16) | (chosen & 0xFF00) | ((chosen >> 16) & 0xFF)
}

/*
Ignore only this running window until the manager exits.
*/
ignoreTargetWindow(*)
{
    ignore_hwnds[menu_target] := true
    refreshWindows()
}

/*
Persist an ignore rule covering the selected app.
*/
ignoreTargetApp(*)
{
    try IniWrite("1", settings_file, "IgnoreApps", WinGetProcessName("ahk_id " menu_target))
    refreshWindows()
}

/*
Persist an ignore rule matching the selected exact window title.
*/
ignoreTargetTitle(*)
{
    try IniWrite("1", settings_file, "IgnoreTitles", WinGetTitle("ahk_id " menu_target))
    refreshWindows()
}

/*
Display ignored rules with an action to remove the selected rule.
*/
showIgnoreList(*)
{
    global ignore_gui, ignore_list
    if (ignore_gui != "")
    {
        ignore_gui.Show()
        return
    }
    ignore_gui := Gui("+Owner" manager_gui.Hwnd " +AlwaysOnTop", "Ignore List")
    ignore_gui.BackColor := "202124"
    ignore_gui.SetFont("s10 cE8EAED", "Segoe UI")
    ignore_list := ignore_gui.AddListView("x8 y8 w460 h280 -Multi", ["Type", "Value"])
    ignore_list.ModifyCol(1, 85)
    ignore_list.ModifyCol(2, 350)
    ignore_gui.AddButton("x8 y298 w150", "Remove Selected").OnEvent("Click", removeIgnored)
    ignore_gui.OnEvent("Close", closeIgnoreList)
    ignore_gui.Show("w476 h336")
    applyDarkTheme(ignore_gui, ignore_list)
    updateIgnoreList()
}

/*
Close the auxiliary ignore list without discarding its rules.
*/
closeIgnoreList(*)
{
    global ignore_gui, ignore_list
    ignore_gui.Destroy()
    ignore_gui := ""
    ignore_list := ""
}

/*
Load persisted app/title rules and temporary window exclusions.
*/
updateIgnoreList()
{
    if (ignore_gui = "")
        return
    ignore_list.Delete()
    for section_name in ["IgnoreApps", "IgnoreTitles"]
    {
        try
        {
            for line in StrSplit(IniRead(settings_file, section_name), "`n")
            {
                split_at := InStr(line, "=")
                if split_at
                    ignore_list.Add("", section_name = "IgnoreApps" ? "App" : "Title", SubStr(line, 1, split_at - 1))
            }
        }
    }
    for hwnd in ignore_hwnds
    {
        try
        {
            if WinExist("ahk_id " hwnd)
                ignore_list.Add("", "Window", hwnd " — " WinGetTitle("ahk_id " hwnd))
        }
    }
}

/*
Remove the chosen ignore rule and show matching windows again.
*/
removeIgnored(*)
{
    row := ignore_list.GetNext()
    if !row
        return
    kind := ignore_list.GetText(row, 1)
    value := ignore_list.GetText(row, 2)
    if (kind = "Window")
    {
        hwnd := Integer(StrSplit(value, " ")[1])
        ignore_hwnds.Delete(hwnd)
    }
    else
        IniDelete(settings_file, kind = "App" ? "IgnoreApps" : "IgnoreTitles", value)
    updateIgnoreList()
    refreshWindows()
}

/*
Use the list's native selection to show the last active external window.
*/
selectActiveRow()
{
    selected_row := window_list.GetNext()
    target_row := 0
    for row, row_hwnd in row_handles
    {
        if (row_hwnd = last_active_hwnd)
        {
            target_row := row
            break
        }
    }
    if (selected_row = target_row)
        return
    if selected_row
        window_list.Modify(selected_row, "-Select")
    if target_row
        window_list.Modify(target_row, "Select")
}

/*
Color each list row according to its app or custom color rule.
*/
onListNotify(w_param, l_param, msg, hwnd)
{
    if (NumGet(l_param, 0, "Ptr") != window_list.Hwnd)
        return
    if (NumGet(l_param, A_PtrSize = 8 ? 16 : 8, "Int") != -12)
        return
    stage_offset := A_PtrSize = 8 ? 24 : 12
    stage := NumGet(l_param, stage_offset, "UInt")
    if (stage = 1)
        return 0x20
    if (stage != 0x10001)
        return
    row := NumGet(l_param, A_PtrSize = 8 ? 56 : 36, "UPtr") + 1
    if !row_colors.Has(row)
        return
    rgb := row_colors[row]
    background := row_topmost.Has(row) && row_topmost[row] ? 0x39424E : 0x202124
    NumPut("UInt", toColorRef(rgb), l_param, A_PtrSize = 8 ? 80 : 48)
    NumPut("UInt", toColorRef(background), l_param, A_PtrSize = 8 ? 84 : 52)
    return 0x2
}
