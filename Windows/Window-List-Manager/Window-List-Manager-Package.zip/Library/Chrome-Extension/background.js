const endpoint = "http://127.0.0.1:18763/domains";
let pending = null;

async function sendDomains() {
  try {
    const all_windows = await chrome.windows.getAll({ populate: true });
    const windows = all_windows.filter((window_item) => window_item.type === "normal").map((window_item) => {
      const tab = window_item.tabs?.find((candidate) => candidate.active);
      let domain = "";
      try {
        const url = new URL(tab?.url || "");
        if (url.protocol === "http:" || url.protocol === "https:") domain = url.hostname.toLowerCase();
      } catch (_) {}
      return {
        title: tab?.title || "",
        domain,
        left: window_item.left || 0,
        top: window_item.top || 0,
        width: window_item.width || 0,
        height: window_item.height || 0
      };
    });
    await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify({ windows })
    });
  } catch (_) {
    // The AHK manager may not be running yet. The next Chrome event retries.
  }
}

function scheduleUpdate() {
  clearTimeout(pending);
  pending = setTimeout(sendDomains, 300);
}

chrome.tabs.onActivated.addListener(scheduleUpdate);
chrome.tabs.onUpdated.addListener(scheduleUpdate);
chrome.tabs.onRemoved.addListener(scheduleUpdate);
chrome.windows.onCreated.addListener(scheduleUpdate);
chrome.windows.onRemoved.addListener(scheduleUpdate);
chrome.windows.onFocusChanged.addListener(scheduleUpdate);
chrome.windows.onBoundsChanged.addListener(scheduleUpdate);
chrome.runtime.onStartup.addListener(scheduleUpdate);
chrome.runtime.onInstalled.addListener(scheduleUpdate);
chrome.alarms.onAlarm.addListener(scheduleUpdate);
chrome.alarms.create("domain-sync", { periodInMinutes: 0.5 });
scheduleUpdate();
