# Run in PowerShell on Windows with AutoHotkey v2 and Ahk2Exe installed.
$ErrorActionPreference = 'Stop'
$library = Split-Path -Parent $MyInvocation.MyCommand.Path
$folder = Split-Path -Parent $library
$source = Join-Path $folder 'Window-List-Manager.ahk'
$icon = Join-Path $library 'Window-List-Manager.ico'
$output = Join-Path $folder 'Window-List-Manager.exe'
$roots = @(${env:ProgramFiles}, ${env:ProgramFiles(x86)}) | Where-Object { $_ }
$compilerCandidates = @($roots | ForEach-Object { Join-Path $_ 'AutoHotkey\Compiler\Ahk2Exe.exe' }) | Where-Object { Test-Path $_ }
$compiler = $compilerCandidates | Select-Object -First 1
if (-not $compiler) {
    $command = Get-Command Ahk2Exe.exe -ErrorAction SilentlyContinue
    if ($command) { $compiler = $command.Source }
}
if (-not $compiler) { throw 'Ahk2Exe.exe was not found. Install the AutoHotkey compiler first.' }
if (-not (Test-Path $source) -or -not (Test-Path $icon)) { throw 'The AHK script or ICO file is missing beside this build script.' }
$baseCandidates = @($roots | ForEach-Object {
    Join-Path $_ 'AutoHotkey\v2\AutoHotkey64.exe'
    Join-Path $_ 'AutoHotkey\v2\AutoHotkey32.exe'
}) | Where-Object { Test-Path $_ }
$base = $baseCandidates | Select-Object -First 1
if (-not $base) { throw 'AutoHotkey v2 executable was not found in the standard installation directories.' }
& $compiler /in $source /out $output /icon $icon /base $base
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $output)) { throw 'Ahk2Exe did not create the executable.' }
Write-Host "Created: $output"
Write-Host 'Keep the Library folder next to the EXE if you use Chrome domain grouping.'
