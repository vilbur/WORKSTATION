param(
    [Parameter(Mandatory = $true)][string]$OutputPath,
    [Parameter(Mandatory = $true)][int]$ManagerPid
)

# Accept domain snapshots only on this computer. Never send browsing data to a remote server.
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 18763)
try {
    $listener.Start()
} catch {
    exit 1
}

try {
    while ($null -ne (Get-Process -Id $ManagerPid -ErrorAction SilentlyContinue)) {
        if (-not $listener.Pending()) {
            Start-Sleep -Milliseconds 150
            continue
        }
        $client = $listener.AcceptTcpClient()
        try {
            $client.ReceiveTimeout = 2000
            $client.SendTimeout = 2000
            $stream = $client.GetStream()
            $raw = [System.Collections.Generic.List[byte]]::new()
            $one = New-Object byte[] 1
            while ($raw.Count -lt 8192) {
                if ($stream.Read($one, 0, 1) -ne 1) { break }
                $raw.Add($one[0])
                $count = $raw.Count
                if ($count -ge 4 -and $raw[$count-4] -eq 13 -and $raw[$count-3] -eq 10 -and $raw[$count-2] -eq 13 -and $raw[$count-1] -eq 10) { break }
            }
            $header = [Text.Encoding]::ASCII.GetString($raw.ToArray())
            $first = ($header -split "`r`n")[0]
            $length_match = [regex]::Match($header, '(?im)^Content-Length:\s*(\d+)')
            $length = if ($length_match.Success) { [int]$length_match.Groups[1].Value } else { 0 }
            if ($first -match '^POST /domains ' -and $length -gt 0 -and $length -le 65536) {
                $body = New-Object byte[] $length
                $offset = 0
                while ($offset -lt $length) {
                    $read = $stream.Read($body, $offset, $length - $offset)
                    if ($read -le 0) { break }
                    $offset += $read
                }
                if ($offset -eq $length) {
                    $payload = [Text.Encoding]::UTF8.GetString($body) | ConvertFrom-Json
                    $lines = [System.Collections.Generic.List[string]]::new()
                    foreach ($item in $payload.windows) {
                        $title = [regex]::Replace([string]$item.title, '[\t\r\n]', ' ')
                        $domain = [string]$item.domain
                        if ($domain -notmatch '^[a-zA-Z0-9.-]{1,253}$') { continue }
                        $lines.Add(($title, $domain, [int]$item.left, [int]$item.top, [int]$item.width, [int]$item.height) -join "`t")
                    }
                    $temporary = "$OutputPath.tmp"
                    [IO.File]::WriteAllText($temporary, ($lines -join "`n"), [Text.UTF8Encoding]::new($false))
                    Move-Item -LiteralPath $temporary -Destination $OutputPath -Force
                }
            }
            $response = "HTTP/1.1 200 OK`r`nAccess-Control-Allow-Origin: *`r`nAccess-Control-Allow-Private-Network: true`r`nAccess-Control-Allow-Headers: content-type`r`nAccess-Control-Allow-Methods: POST, OPTIONS`r`nContent-Length: 2`r`nConnection: close`r`n`r`nOK"
            $bytes = [Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($bytes, 0, $bytes.Length)
        } catch {
            # A malformed local request must not terminate the listener.
        } finally {
            $client.Close()
        }
    }
} finally {
    $listener.Stop()
    Remove-Item -LiteralPath $OutputPath -Force -ErrorAction SilentlyContinue
}
